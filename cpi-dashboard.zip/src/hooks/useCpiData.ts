import { useMemo } from 'react';
export default function useCpiData(){ return useMemo(()=>[],[]);}
