// Replace with your real line chart implementation
export default function LineCpiChart(){ return <div className="h-64 flex items-center justify-center text-slate-500">Line chart goes here</div>}
